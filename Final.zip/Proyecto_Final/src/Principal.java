import processing.core.PApplet;
import processing.core.PImage;

public class Principal extends PApplet
{

	public static void main(String[] args) 
	{
		PApplet.main("Principal");
	}
	
	@Override
	public void settings() //void Awake
	{
		size(600, 600);
	}

	int dirtPathColor;
	TheMainCharacter player;
	int playerX, playerY;

	PImage dirtTiles;
	
	PImage characterDown, characterUp, characterLeft, characterRight, characterWalkRight, characterWalkLeft, characterWalkUp, characterWalkDown;
	
	PImage healthyHeart, brokenHeart;
	
	PImage door;
	
	PImage sword;
	
	Tilemap tilemap;
	
	int doorX, doorY;
	
	int healthyHeartOneX, healthyHeartOneY, healthyHeartTwoX, healthyHeartTwoY, healthyHeartThreeX, healthyHeartThreeY, health;
	
	companion stageOneCompanion, stageTwoCompanion, stageThreeCompanion, stageFourCompanion, stageFiveCompanion;
	
	Enemy enemyStageSix, enemyStageSixTwo, enemyStageSeven, enemyStageSevenTwo, enemyStageSevenThree;
	
	int enemyX1, enemyY1, enemyX2, enemyY2, enemyX3, enemyX4, enemyX5, enemyY3, enemyY4, enemyY5;
	
	int invFrames;
	boolean invFramesActive;
	
	boolean hasSword, hasKey;
	
	int stage;
	@Override
	public void setup() //void Start
	{
		dirtPathColor = color(121, 89, 56);
		player = new TheMainCharacter(25, 25);
		
		playerX = player.getX();
		playerY = player.getY();
		
		dirtTiles = loadImage("TL14.png");
		
		door = loadImage("door.png");
		
		sword = loadImage("sword.png");
		
		characterDown = loadImage("Character1.png");
		characterLeft = loadImage("Character4.png");
		characterRight = loadImage("Character7.png");
		characterUp = loadImage("Character10.png");
		
		characterWalkDown = loadImage("Character2.png");
		characterWalkUp = loadImage("Character11.png");
		characterWalkLeft = loadImage("Character5.png");
		characterWalkRight = loadImage("Character8.png");
		
		stage = 1;
		
		doorX = 250;
		doorY = 250;
		
		hasSword = false;
		hasKey = false;
		
		tilemap = new Tilemap(this);
		
		enemyStageSix = new Enemy(50, 300, true, this);
		enemyStageSixTwo = new Enemy(150, 300, true, this);
		enemyStageSeven = new Enemy(50, 300, true, this);
		enemyStageSevenTwo = new Enemy(100, 350, true, this);
		enemyStageSevenThree = new Enemy(400, 250, true, this);
		
		enemyX1 = enemyStageSix.getX();
		enemyX2 = enemyStageSixTwo.getX();
		enemyY1 = enemyStageSix.getY();
		enemyY2 = enemyStageSixTwo.getY();
		
		enemyX3 = enemyStageSeven.getX();
		enemyY3 = enemyStageSeven.getY();
		enemyX4 = enemyStageSevenTwo.getX();
		enemyY4 = enemyStageSevenTwo.getY();
		enemyX5 = enemyStageSevenThree.getX();
		enemyY5 = enemyStageSevenThree.getY();
		
		stageOneCompanion = new companion(575, 275, "Walk north to find the castle,\n or south to find the river", 375, 375);	
		stageTwoCompanion = new companion(375, 375, "The castle's door seems locked, \n we need a key", 375, 275);
		stageThreeCompanion = new companion(525, 125, "There's a barrel on the other \n side of the river.", 325, 25);
		stageFourCompanion = new companion(475, 125, "Perhaps you can reach the other \n side with this bridge", 375, 25);
		stageFiveCompanion = new companion(275, 275, "You might need a weapon \n for the next part", 325, 275);
	}
	
	@Override
	public void draw() //void Update
	{		
		background(dirtPathColor);
		System.out.println(playerX + ", " + playerY);
		
		strokeWeight(1);
		stroke(0);
		noFill();
		
		//Fill the window with the brown dirt tiles
		for(int xM = 0; xM < 600; xM += 50)
		{
			for(int yM = 0; yM < 600; yM += 50)
			{
				square(xM, yM, 50);
				image(dirtTiles, xM, yM);
			}
		}
		
		player.paint(this);
		player.setX(playerX);
		player.setY(playerY);

		switch(stage)
		{
			case 1:
				tilemap(1);
				limiter(1);
				break;
			case 2:
				tilemap(2);
				limiter(2);
				break;
			case 3:
				tilemap(3);
				limiter(3);
				break;
			case 4:
				tilemap(4);
				limiter(4);
				break;
			case 5:
				tilemap(5);
				limiter(5);
				break;
			case 6:
				tilemap(6);
				limiter(6);
				break;
			case 7:
				tilemap(7);
				limiter(7);
				break;
		}
		
		characterMovement();
		companionHint();
		attack();
		
		enemies();
	
	}
	
	public void keyPressed()
	{
		switch(key)
		{
		case 'w':
			playerY -= 50;
			break;
		case 'W':
			playerY -= 50;
			break;
		case 's':
			playerY += 50;
			break;
		case 'S':
			playerY += 50;
			break;
		case 'a':
			playerX -= 50;
			break;
		case 'A':
			playerX -= 50;
			break;
		case 'd':
			playerX += 50;
			break;
		case 'D':
			playerX += 50;
			break;
		}
		
		switch(key)
		{
		case '1':
			stage = 1;
			break;
		case '2':
			stage = 2;
			break;
		case '3':
			stage = 3;
			break;
		case '4':
			stage = 4;
			break;
		case '5':
			stage = 5;
			break;
		case '6':
			stage = 6;
			break;
		case '7':
			stage = 7;
			break;
		case '8':
			stage = 8;
			break;
		case '9':
			stage = 9;
			break;
		case '0':
			stage = 10;
			break;
		}
		
	}
	
	public void tilemap(int i)
	{	
		if(i == 1)
		{
			tilemap.display(1, this);
		}
		if(i == 2)
		{
			tilemap.display(2, this);
			
			image(door, doorX, doorY);
			image(door, doorX + 50, doorY);
			image(door, doorX, doorY + 50);
			image(door, doorX + 50, doorY + 50);
		}
		if(i == 3)
		{
			tilemap.display(3, this);
		}
		if(i == 4)
		{
			tilemap.display(4, this);
		}
		if(i == 5)
		{
			tilemap.display(5, this);
		}
		if(i == 6)
		{
			tilemap.display(6, this);
		}
		if(i == 7)
		{
			tilemap.display(7, this);
		}
		if(i == 8)
		{
			tilemap.display(8, this);
		}
		if(i == 9)
		{
			tilemap.display(9, this);
		}
		if(i == 10)
		{
			tilemap.display(10, this);
		}
}
	
	public void limiter(int i) 
	{
	if(i == 1) 
	{
		if(playerX > 600)
		{
			playerX = 575;
		}
		if(playerX < 0)
		{
			playerX = 25;
		}
		if(playerY > 600 && (playerX < 175) && (playerX > 275))
		{
			playerY = 575;
		} 
		if(playerY < 0 && playerX < 100)
		{
			playerY = 25;
		}
		
		if(playerY > 400 && playerX == 25)
		{
			playerX = 25;
			playerY = 375;
		}
		if(playerY > 400 && playerX == 75)
		{
			playerX = 75;
			playerY = 375;
		}
		if(playerY == 425 && playerX == 125)
		{
			playerX = 125;
			playerY = 375;
		}
		if(playerY == 425 && playerX == 125)
		{
			playerX = 175;
			playerY = 425;
		}
		
		if(playerX == 125 && playerY == 25)
		{
			playerX = 75;
			playerY = 25;
		}
		if(playerX == 125 && playerY == 75)
		{
			playerX = 75;
			playerY = 75;
		}
		if(playerX == 125 && playerY == 125)
		{
			playerX = 75;
			playerY = 125;
		}
		if(playerX == 125 && playerY == 175)
		{
			playerX = 75;
			playerY = 175;
		}
		if(playerX == 175 && playerY == 175)
		{
			playerX = 175;
			playerY = 225;
		}
		if(playerX == 225 && playerY == 25)
		{
			playerX = 275;;
			playerY = 25;
		}
		if(playerX == 225 && playerY == 75)
		{
			playerX = 275;;
			playerY = 75;
		}
		if(playerX == 225 && playerY == 125)
		{
			playerX = 275;;
			playerY = 125;
		}
		if(playerX == 125 && playerY == 475)
		{
			playerX = 175;
			playerY = 475;
		}
		if(playerX == 125 && playerY == 525)
		{
			playerX = 175;
			playerY = 525;
		}
		if(playerX == 125 && playerY == 575)
		{
			playerX = 175;
			playerY = 575;
		}
		if(playerX == 325 && playerY == 575)
		{
			playerX = 275;
			playerY = 575;
		}
		if(playerX == 325 && playerY == 525)
		{
			playerX = 275;
			playerY = 525;
		}
		if(playerX == 325 && playerY == 475)
		{
			playerX = 275;
			playerY = 475;
		}
		if(playerX == 325 && playerY == 425)
		{
			playerX = 275;
			playerY = 425;
		}
		if(playerX == 325 && playerY == 375)
		{
			playerX = 275;
			playerY = 375;
		}
		if(playerX == 375 && playerY == 375)
		{
			playerX = 375;
			playerY = 325;
		}
		if(playerX == 425 && playerY == 375)
		{
			playerX = 425;
			playerY = 325;
		}
		if(playerX == 475 && playerY == 375)
		{
			playerX = 475;
			playerY = 325;
		}
		if(playerX == 525 && playerY == 375)
		{
			playerX = 525;
			playerY = 325;
		}
		if(playerX == 575 && playerY == 375)
		{
			playerX = 575;
			playerY = 325;
		}
		if(playerX == 625 && playerY == 325)
		{
			playerX = 575;
			playerY = 325;
		}
		if(playerX == 625 && playerY == 275)
		{
			playerX = 575;
			playerY = 275;
		}
		if(playerX == 625 && playerY == 225)
		{
			playerX = 575;
			playerY = 225;
		}
		if(playerX == 625 && playerY == 175)
		{
			playerX = 575;
			playerY = 175;
		}
		if(playerX == 625 && playerY == 125)
		{
			playerX = 575;
			playerY = 125;
		}
		if(playerX == 625 && playerY == 75)
		{
			playerX = 575;
			playerY = 75;
		}
	}
	
	else if(i == 2)
	{
		if(playerX == doorX + 75 && playerY == doorY + 75)
		{
			playerY = 375;
		}
		if(playerX == doorX + 25 && playerY == doorY + 75)
		{
			playerY = 375;
		}
		
		
		if(playerX > 600)
		{
			playerX = 575;
		}
		if(playerX < 0)
		{
			playerX = 25;
		}
		if(playerY < 0)
		{
			playerY = 25;
		}
		
		if(playerY == 325 && !(playerX == 275) && !(playerX == 325))
		{
			playerY = 375;
		}
		
		if(playerX == 225 && playerY == 575)
		{
			playerX = 275;
		}
		if(playerX == 225 && playerY == 525)
		{
			playerX = 275;
		}
		if(playerX == 225 && playerY == 475)
		{
			playerX = 275;
		}
		if(playerX == 175 && playerY == 475)
		{
			playerY = 425;
		}
		if(playerX == 125 && playerY == 475)
		{
			playerY = 425;
		}
		if(playerX == 75 && playerY == 475)
		{
			playerY = 425;
		}
		if(playerX == 25 && playerY == 475)
		{
			playerY = 425;
		}
	}
	
	else if(i == 3)
	{
		if(playerY == 275)
		{
			playerY = 225;
		}
		
		if(playerX == 125 && playerY == 25)
		{
			playerX = 175;
		}
		if(playerX == 125 && playerY == 75)
		{
			playerX = 175;
		}
		if(playerX == 75 && playerY == 75)
		{
			playerY = 125;
		}
		if(playerX == 25 && playerY == 75)
		{
			playerY = 125;
		}
		if(playerX == 325 && playerY == 25)
		{
			playerX = 275;
		}
		if(playerX == 325 && playerY == 75)
		{
			playerX = 275;
		}
		if(playerX == 375 && playerY == 75)
		{
			playerY = 125;
		}
		if(playerX == 425 && playerY == 75)
		{
			playerY = 125;
		}
		if(playerX == 475 && playerY == 75)
		{
			playerY = 125;
		}
		if(playerX == 525 && playerY == 75)
		{
			playerY = 125;
		}
		if(playerX == 575 && playerY == 75)
		{
			playerY = 125;
		}
		if(playerY == 375)
		{
			playerY = 425;
		}
		if(playerY == 525)
		{
			playerY = 475;
		}
	}
	
	else if(i == 4)
	{
		if(playerY == 275 && !(playerX == 325) && !(playerX == 375))
		{
			playerY = 225;
		}
		if(playerY == 375 && !(playerX == 325) && !(playerX == 375))
		{
			playerY = 425;
		}
		if(playerX == 275 && playerY == 325)
		{
			playerX = 325;
		}
		if(playerX == 425 && playerY == 325)
		{
			playerX = 375;
		}
		if(playerY == 75)
		{
			playerY = 125;
		}
		if(playerY == 525)
		{
			playerY = 475;
		}
		if(playerX == 575)
		{
			playerX = 525;
		}
		if(playerX == 525 && playerY == 125)
		{
			playerX = 475;
		}
	}
	
	else if(i == 5)
	{
		if(playerX < 0)
		{
			playerX = 25;
		}
		if(playerX > 275 && playerY == 275)
		{
			playerY = 225;
		}
		
		if(playerY > 300 && playerX == 325)
		{
			playerX = 275;
		}
		
		if(playerX > 75 && playerY == 525)
		{
			playerY = 475;
		}
		
		if(playerX >= 475 && playerY == 375)
		{
			playerY = 425;
		}
		
		if(playerX == 425 && playerY > 300)
		{
			playerX = 475;
		}
		
		if(playerY == 75)
		{
			playerY = 125;
		}
		
		if(playerX == 175 && playerY == 125)
		{
			playerX = 225;
		}
		
		if(playerX == 125 && playerY == 175)
		{
			playerX = 175;
		}
		
		if(playerX == 125 && playerY == 575)
		{
			playerX = 75;
		}
		
		if(playerX == 75 && playerY == 225)
		{
			playerX = 125;
		}
		
		if(playerX == 25 && playerY == 275)
		{
			playerX = 75;
		}
	}
	
	else if(i == 6)
	{
		if(playerX < 0)
		{
			playerX = 25;
		}
		
		if(playerX == 325)
		{
			playerX = 275;
		}
		
		if(playerX == 175 && playerY < 175)
		{
			playerX = 125;
		}
		
		if(playerY == 125 && playerX > 175)
		{
			playerY = 175;
		}
	}
	
	else if(i == 7)
	{
		if(playerX < 0 && !(playerY == 325) && !(playerY == 375))
		{
			playerX = 25;
		}
		
		if(playerX == 325 && !(playerY == 225) && !(playerY == 275) && !(playerY == 325))
		{
			playerX = 275;
		}
		
		if(playerY == 175 && playerX > 275)
		{
			playerY = 225;
		}
		
		if(playerY == 375 && playerX > 275)
		{
			playerY = 325;
		}
	}
	}
	
	public void companionHint()
	{
		if(stage == 1)
		{
			stageOneCompanion.paint(this);
			
			text("Press 'Z' to interact", 375, 450);
			
			if(playerY == -25)
			{
				playerY = 575;
				stage = 2;
			}
			
			if(playerY == 625)
			{
				playerY = 25;
				stage = 3;
			}
		}
		
		if(stage == 2)
		{
			stageTwoCompanion.paint(this);
			
			if(playerY == 625)
			{
				stage = 1;
				playerY = 25;
			}
		}
		if(stage == 3)
		{
			stageThreeCompanion.paint(this);
			
			if(keyPressed)
			{
				if(key == 'z' && dist(playerX, playerY, 175, 475) < 75)
				{
					hasSword = true;
					text("You found a sword... with four blades \n Press 'X' to attack", 255, 525);
				}
			}
			
			if(playerY == -25)
			{
				stage = 1;
				playerY = 575;
			}
			if(playerX == 625)
			{
				stage = 4;
				playerX = 25;
			}
			if(playerX == -25)
			{
				stage = 5;
				playerX = 575;
			}
		}
		
		if(stage == 4)
		{
			stageFourCompanion.paint(this);
			
			if(playerX == -25)
			{
				stage = 3;
				playerX = 575;
			}
		}
		
		if(stage == 5) 
		{
			stageFiveCompanion.paint(this);
			
			if(playerX == 625)
			{
				stage = 3;
				playerX = 25;
			}
			
			if(playerY == 625)
			{
				stage = 6;
				playerY = 25;
			}
		}
		
		if(stage == 6)
		{
			if(playerY == -25)
			{
				stage = 5;
				playerY = 575;
			}
		
			if(playerY == 625)
			{
				stage = 7;
				playerY = 25;
			}
		}
		
		if(stage == 7)
		{
			if(playerY == -25)
			{
				stage = 6;
				playerY = 575;
			}
			if(playerX == -25)
			{
				stage = 8;
				playerX = 575;
			}
			if(playerX == 625)
			{
				stage = 10;
				playerX = 25;
			}
			if(playerY == 625)
			{
				stage = 9;
				playerY = 25;
			}
		}
		if(stage == 8)
		{
			if(playerX == 625)
			{
				stage = 7;
				playerX = 25;
			}
		}
		if(stage == 9)
		{
			if(playerY == -25)
			{
				stage = 7;
				playerY = 575;
			}
		}
		if(stage == 10)
		{
			if(playerX == -25)
			{
				stage = 7;
				playerX = 575;
			}
		}
		
		if((dist(playerX, playerY, stageOneCompanion.getX(), stageOneCompanion.getY()) < 100) && keyPressed && stage == 1)
		{
			if(key == 'Z' || key == 'z') 
			{
				stageOneCompanion.hint(this);
			}
		}
		if((dist(playerX, playerY, stageTwoCompanion.getX(), stageTwoCompanion.getY()) < 100) && keyPressed && stage == 2)
		{
			if(key == 'Z' || key == 'z') 
			{
				stageTwoCompanion.hint(this);
			}
		}
		if((dist(playerX, playerY, stageThreeCompanion.getX(), stageThreeCompanion.getY()) < 100) && keyPressed && stage == 3)
		{
			if(key == 'Z' || key == 'z') 
			{
				stageThreeCompanion.hint(this);
			}
		}
		if((dist(playerX, playerY, stageFourCompanion.getX(), stageFourCompanion.getY()) < 100) && keyPressed && stage == 4)
		{
			if(key == 'Z' || key == 'z') 
			{
				stageFourCompanion.hint(this);
			}
		}
		if((dist(playerX, playerY, stageFiveCompanion.getX(), stageFiveCompanion.getY()) < 100) && keyPressed && stage == 5)
		{
			if(key == 'Z' || key == 'z') 
			{
				stageFiveCompanion.hint(this);
			}
		}
	}
	
	public void characterMovement()
	{
		if(keyPressed) 
		{
			if(key == 'w' || key == 'W')
			{
				image(characterWalkUp, playerX - 25, playerY - 25);
			}
			else if(key == 's' || key == 'S')
			{
				image(characterWalkDown, playerX - 25, playerY - 25);
			}
			else if(key == 'd' || key == 'D')
			{
				image(characterWalkRight, playerX - 25, playerY - 25);
			}
			else if(key == 'a' || key == 'A')
			{
				image(characterWalkLeft, playerX - 25, playerY - 25);
			}
			else
			{
				image(characterDown, playerX - 25, playerY - 25);
			}
		}
		else
		{
			image(characterDown, playerX - 25, playerY - 25);
		}
	}
	
	public void enemies()
	{
		
		if(stage == 6)
		{
			enemyStageSix.paint(this);
			enemyStageSixTwo.paint(this);
			
			if(playerY > enemyStageSix.getY())
			{
				enemyStageSix.moveDown();
			}
			else if(playerY < enemyStageSix.getY())
			{
				enemyStageSix.moveUp();
			}
			if(playerY < enemyStageSixTwo.getY())
			{
				enemyStageSixTwo.moveUp();
			}
			else if(playerY > enemyStageSixTwo.getY())
			{
				enemyStageSixTwo.moveDown();
			}
			
			if(playerX > enemyStageSix.getX())
			{
				enemyStageSix.moveRight();
			}
			else if(playerX < enemyStageSix.getX())
			{
				enemyStageSix.moveLeft();
			}
			if(playerX > enemyStageSixTwo.getX())
			{
				enemyStageSixTwo.moveRight();
			}
			else if(playerX < enemyStageSixTwo.getX())
			{
				enemyStageSixTwo.moveLeft();
			}
			
			if(keyPressed) 
			{
				if(dist(playerX, playerY, enemyStageSix.getX(), enemyStageSix.getY())< 20 && key == 'x' || key == 'X')
				{
					enemyStageSix.setY(90000);
				}
				if(dist(playerX, playerY, enemyStageSixTwo.getX(), enemyStageSixTwo.getY())< 20 && key == 'x' || key == 'X')
				{
					enemyStageSixTwo.setY(90000);
				}
			}
		}
		
		if(stage == 7)
		{
			enemyStageSeven.paint(this);
			enemyStageSevenTwo.paint(this);
			enemyStageSevenThree.paint(this);
			
			if(playerY > enemyStageSeven.getY())
			{
				enemyStageSeven.moveDown();
			}
			else if(playerY < enemyStageSeven.getY())
			{
				enemyStageSeven.moveUp();
			}
			if(playerY < enemyStageSevenTwo.getY())
			{
				enemyStageSevenTwo.moveUp();
			}
			else if(playerY > enemyStageSevenTwo.getY())
			{
				enemyStageSevenTwo.moveDown();
			}
			if(playerY > enemyStageSevenThree.getY())
			{
				enemyStageSevenThree.moveDown();
			}
			else if(playerY < enemyStageSevenThree.getY())
			{
				enemyStageSevenThree.moveUp();
			}
			
			if(playerY > enemyStageSeven.getX())
			{
				enemyStageSeven.moveRight();
			}
			else if(playerY < enemyStageSeven.getX())
			{
				enemyStageSeven.moveLeft();
			}
			if(playerY < enemyStageSevenTwo.getX())
			{
				enemyStageSevenTwo.moveLeft();
			}
			else if(playerY > enemyStageSevenTwo.getX())
			{
				enemyStageSevenTwo.moveRight();
			}
			if(playerY > enemyStageSevenThree.getX())
			{
				enemyStageSevenThree.moveRight();
			}
			else if(playerY < enemyStageSevenThree.getX())
			{
				enemyStageSevenThree.moveLeft();
			}
			
			if(keyPressed) 
			{
				if(dist(playerX, playerY, enemyStageSeven.getX(), enemyStageSeven.getY())< 20 && key == 'x' || key == 'X')
				{
					enemyStageSeven.setY(90000);
				}
				if(dist(playerX, playerY, enemyStageSevenTwo.getX(), enemyStageSevenTwo.getY())< 20 && key == 'x' || key == 'X')
				{
					enemyStageSevenTwo.setY(90000);
				}
				if(dist(playerX, playerY, enemyStageSevenThree.getX(), enemyStageSevenThree.getY())< 20 && key == 'x' || key == 'X')
				{
					enemyStageSevenThree.setY(90000);
				}
			}
			
		}
		
		if(stage == 8)
		{
			
		}
		if(stage == 9)
		{
			
		}
		if(stage == 10)
		{
			
		}
	}

	public void attack()
	{
		if(keyPressed)
		{
			if(key == 'x' || key == 'X' && hasSword)
			{
				image(sword, playerX - 75, playerY - 75);
			}
		}
	}
}
